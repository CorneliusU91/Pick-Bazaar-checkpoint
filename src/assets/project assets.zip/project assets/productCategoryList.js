const pdCatList = [
    {
        url: "/category/bakery/juice.png",
        name: "Juice",
    },
    {
        url: "/category/bakery/coffe.png",
        name: "Coffee & Tea",
    },
    {
        url: "/category/bakery/cookies.png",
        name: "Cookies",
    },
    {
        url: "/category/bakery/cake.png",
        name: "Round Cake",
    
    },
    {
        url: "/category/bakery/bread.png",
        name: "Pita Bread",
    },
    {
        url: "/category/bakery/scake.png",
        name: "Sliced Cake",
    },
    {
        url: "/category/bakery/muffin.png",
        name: "Muffin",
    },
    {
        url: "/category/bakery/danish.png",
        name: "Danish",
    },
    {
        url: "/category/bakery/croissants.png",
        name: "Croissants",
    },
    {
        url: "/category/bakery/pie.png",
        name: "Feeter & Pies", 
    },
    {
        url: "/category/bakery/loaf.png",
        name: "Toast & Loaf",
    },
    {
        url: "/category/bakery/softbread.png",
        name: "Soft Bread",
    },
    {
        url: "/category/bakery/bakery.jpg",
        name: "Bakery",
    },
]

export default pdCatList;